All Ok at Affiliate:
https://prnt.sc/dQ07qUA-s_NK
https://prnt.sc/DmEDiRSb4y6I
https://prnt.sc/h3y60C5vIUS3
https://prnt.sc/m4j5BxWgsSRr
https://prnt.sc/6qRSynmT-8F8
https://prnt.sc/XC9CjExVnXzJ
https://prnt.sc/jkhHz47e7YiY
https://prnt.sc/Q0w-se3T63wy
https://prnt.sc/YRUbGBr84lFg




=====================
buttons ki size kuch pages me theek ni h, for example
admin me is page pr http://127.0.0.1:8000/settings
affilate me is page pr submit button ni h and size bhi same rakhna http://127.0.0.1:8001/testPostback















