<?php $__env->startSection('content'); ?>
<?php
   use Illuminate\Support\Facades\Http;
?>

<div class="bg-[#f2f2f2] p-[15px] md:p-[35px]">
    <div class="bg-[#fff] p-[15px] md:p-[20px] rounded-[10px] mb-[20px]">
       <div class="flex items-center justify-between gap-[25px] w-[100%]  mb-[15px]">
          <h2 class="text-[20px] text-[#1A1A1A] font-[600]">Overview</h2>
          <button
             class="w-[140px] bg-[#D272D2] px-[20px] py-[10px] w-[100px] rounded-[4px] text-[14px] font-[500] text-[#fff] text-center" id="exportCsvBtn">Export</button>
       </div>
       <div class="flex flex-col items-center justify-center gap-[15px]">
         <form method="get" id="filterConversions">
          <div class="w-full flex flex-col gap-[10px]">
            <div class="w-[100%] flex flex-col lg:flex-row items-start lg:items-center justify-start gap-[10px]">
               <label class="min-w-[160px] w-[100%] md:w-[10%] text-[14px] font-[500] text-[#898989] ">Apps:</label>
               <select name="appid" class="appendAffiliateApps w-[100%] lg:w-[90%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[400] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none">
                  <option value="" >Select</option>
                  <?php if($allAffiliatesApp && $allAffiliatesApp->isNotEmpty()): ?>
                     <?php $__currentLoopData = $allAffiliatesApp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $affiliateApp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($affiliateApp->id); ?>" <?php if(isset($requestedParams['appid']) && $requestedParams['appid'] == $affiliateApp->id): ?> selected <?php endif; ?>><?php echo e($affiliateApp->appName); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
               </select>
            </div>
             <div class="w-[100%] flex flex-col lg:flex-row items-start lg:items-center justify-start gap-[10px]">
                <label class="min-w-[160px] w-[100%] md:w-[10%] text-[14px] font-[500] text-[#898989] ">Range:</label>
                <input type="text" name="range" class="dateRange-report w-[100%] bg-[#F6F6F6] px-[15px] py-[12px] text-[12px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none" placeholder="2024-12-10" value="<?php echo e($requestedParams['range']); ?>">
             </div>
             <div class="w-[100%] flex flex-col lg:flex-row items-start lg:items-center justify-start gap-[10px]">
                <label class="min-w-[160px] w-[10%] text-[14px] font-[500] text-[#898989] ">Country:</label>
                <select name="country" class="countryOptions w-[100%] lg:w-[90%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none">
                  <option value="">Select</option>
                  <?php $__currentLoopData = $allCountry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countryName =>$countryCode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($countryCode); ?>" <?php if(isset($requestedParams['country']) && $requestedParams['country'] == $countryCode): ?> selected <?php endif; ?>><?php echo e($countryName); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
             </div>
             <div class="w-[100%] flex items-center flex-wrap justify-start lg:flex-nowrap gap-[10px]">
                <label class="min-w-[160px] w-[10%] text-[14px] font-[500] text-[#898989] ">Filter by:</label> 
                <div class="w-[100%] xl:w-[90%] flex flex-wrap xl:flex-nowrap  items-center gap-[5px] md:gap-[8px] lg:gap-[10px] xl:gap-[15px]">
                   <div class="relative w-[100%] xl:w-[80%] flex flex-wrap xl:flex-nowrap items-center gap-[10px]">
                      <select name="offer"
                         class="offerOption w-[100%] xl:w-[25%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none">
                         <option value="">Select</option>
                         <?php $__currentLoopData = $allOffers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offerKey => $offerName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($offerKey); ?>" <?php if(isset($requestedParams['offer']) && $requestedParams['offer'] == $offerKey): ?> selected <?php endif; ?>><?php echo e($offerName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <select name="os"
                         class="osOption w-[100%] xl:w-[25%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none">
                         <option value="">Select</option>
                         <?php if($allOs->isNotEmpty()): ?>
                         <?php $__currentLoopData = $allOs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $osList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($osList); ?>" <?php if(isset($requestedParams['os']) && $requestedParams['os'] == $osList): ?> selected <?php endif; ?>><?php echo e($osList); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                      </select>
                      
                      <input name="goal" class="w-[100%] xl:w-[25%] bg-[#F6F6F6] px-[15px] py-[12px] text-[14px] font-[600] text-[#4D4D4D] border-[1px] border-[#E6E6E6] rounded-[4px] hover:outline-none focus:outline-none" placeholder="Goal" value="<?php echo e($requestedParams['goal'] ?? ''); ?>">
                      
                   </div>
                   <div class="w-[100%] xl:w-[20%] flex items-center justify-start xl:justify-between gap-[10px]">
                      <button
                         class="w-[140px] bg-[#D272D2] px-[20px] py-[11px] w-[100px] rounded-[4px] text-[14px] font-[500] text-[#fff] text-center">Apply</button>
                      <a href="<?php echo e(route('report.conversions')); ?>"
                         class="w-[140px] bg-[#F5EAF5] px-[20px] py-[11px] w-[100px] border border-[#F5EAF5] rounded-[4px] text-[14px] font-[500] text-[#D272D2] text-center">Clear</a>
                   </div>
                </div>
             </div>
          </div>
         </form>
       </div>
      <?php
      $exportedData = [
            'heading' => [
               '0' => 'Click Id',
               '1' => 'Conversion Id',
               '2' => 'Click Date',
               '3' => 'Conversion Date',
               '4' => 'Status',
               '5' => 'Offer',
               '6' => 'Goal',
               '7' => 'Payout',
               '8' => 'Country',
               '9' => 'IP',
               '10' => 'OS',
               '11' => 'Device',
               '12' => 'Mobile ISP',
               '13' => 'User Agent',
            ],
            'data' => []
         ]; 
       ?>
       <div class="flex flex-col justify-between items-center gap-[5px] w-[100%] mt-[30px] ">
          <div class="w-[100%] overflow-x-scroll tableScroll">
             <table
                class="w-[100%] border-collapse border-spacing-0 rounded-[10px] border-separate border border-[#E6E6E6]">
                <tr>
                  <th
                      class="bg-[#F6F6F6] rounded-tl-[10px] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap ">
                      Click Id
                   </th>
                   <th
                      class=" whitespace-normal breakword bg-[#F6F6F6] rounded-tr-[10px] text-[10px] text-center font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left">
                      Conversion Id
                   </th>
                   <th
                      class="bg-[#F6F6F6] rounded-tl-[10px] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap ">
                      Click Date
                   </th>
                   <th
                      class="bg-[#F6F6F6] rounded-tl-[10px] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap ">
                      Conversion Date
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      Status
                   </th>
                   <th
                      class=" whitespace-normal breakword bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left">
                      Offer
                   </th>
                   <th
                      class=" whitespace-normal breakword bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left">
                      Goal
                   </th>
                   <th
                      class=" whitespace-normal breakword bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left">
                      Payout
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      Country
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      IP
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      OS
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      Device
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      Mobile ISP
                   </th>
                   <th
                      class="bg-[#F6F6F6] text-[10px] font-[500] text-[#1A1A1A] px-[10px] py-[13px] text-left whitespace-nowrap">
                      User Agent
                   </th>
                </tr>
                <?php if($allConversions->isNotEmpty()): ?>
                <?php $__currentLoopData = $allConversions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $conversion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap border-b-[1px] border-b-[#E6E6E6]">
                      <?php echo e($conversion->click_id); ?>

                      <?php $exportedData['data'][$key]['click_id'] = $conversion->click_id ?? '0'; ?>
                   </td>
                   <td title="AU - Ipsos iSay (TOI) [Responsive]" 
                      class="  whitespace-normal breakword text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left border-b-[1px] border-b-[#E6E6E6] ">
                      <?php echo e($conversion->conversion_id); ?>

                      <?php $exportedData['data'][$key]['conversion_id'] = $conversion->conversion_id ?? '0'; ?>
                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left border-b-[1px] border-b-[#E6E6E6] ">
                      <?php echo e($conversion->click_time); ?>

                      <?php $exportedData['data'][$key]['click_time'] = $conversion->click_time ?? '0'; ?>
                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left  border-b-[1px] border-b-[#E6E6E6]">
                      <?php echo e($conversion->created_at); ?>

                      <?php $exportedData['data'][$key]['created_at'] = $conversion->created_at ?? '0'; ?>
                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap border-b-[1px] border-b-[#E6E6E6]">
                      <div class="inline-flex bg-[#F3FEE7] border border-[#BCEE89] rounded-[5px]  px-[8px] py-[4px] text-[10px] font-[600] text-[#6EBF1A] text-center uppercase">Confirmed</div>
                      <?php $exportedData['data'][$key]['status'] = 'Confirmed'; ?>
                      
                      
                   </td>
                   <?php
                        $url = $advertiserDetails->affise_endpoint.'offer/'.$conversion->offer_id;
                        $response = HTTP::withHeaders([
                           'API-Key' => $advertiserDetails->affise_api_key,
                        ])->get($url);
                        if ($response->successful()) {
                           $offerDetails = $response->json();
                           $conversion->offer_id = ucfirst($offerDetails['offer']['title']);
                        }
                   ?>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap border-b-[1px] border-b-[#E6E6E6]">
                      <?php echo e($conversion->offer_id); ?>

                      <?php $exportedData['data'][$key]['offer_id'] = $conversion->offer_id ?? '0'; ?>
                   </td>
                     <?php
                        $goalConv = ($conversion->goal == '') ? '--' : $conversion->goal;
                     ?>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap border-b-[1px] border-b-[#E6E6E6]">
                       <?php echo e($goalConv); ?>

                       <?php $exportedData['data'][$key]['goal'] = $goalConv ?? '--'; ?>
                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap border-b-[1px] border-b-[#E6E6E6]">
                       $ <?php echo e($conversion->payout); ?>

                       <?php $exportedData['data'][$key]['payout'] = '$ '.$conversion->payout ?? 'N/A'; ?>
                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap border-b-[1px] border-b-[#E6E6E6] ">
                       <?php echo e($conversion->country_name); ?>

                       <?php $exportedData['data'][$key]['country_name'] = $conversion->country_name ?? 'N/A'; ?>
                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap border-b-[1px] border-b-[#E6E6E6]">
                       <?php echo e($conversion->ip); ?>

                       <?php $exportedData['data'][$key]['ip'] = $conversion->ip ?? 'N/A'; ?>
                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap border-b-[1px] border-b-[#E6E6E6] ">
                       <?php echo e($conversion->device_os); ?>

                       <?php $exportedData['data'][$key]['device_os'] = $conversion->device_os ?? 'N/A'; ?>
                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap border-b-[1px] border-b-[#E6E6E6]">
                       <?php echo e($conversion->device_type ?? 'Unknown'); ?>

                       <?php $exportedData['data'][$key]['device_type'] = $conversion->device_type ?? 'Unknown'; ?>
                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] px-[10px] py-[10px] text-left whitespace-nowrap border-b-[1px] border-b-[#E6E6E6]">
                      <?php echo e($conversion->isp ?? 'Unknown'); ?>

                      <?php $exportedData['data'][$key]['isp'] = $conversion->isp ?? 'Unknown'; ?>
                   </td>
                   <td
                      class="text-[10px] font-[500] text-[#808080] text-center px-[10px] py-[10px] text-left  border-b-[1px] border-b-[#E6E6E6]">
                      <?php echo e($conversion->ua); ?>

                      <?php $exportedData['data'][$key]['ua'] = $conversion->ua ?? 'N/A'; ?>
                   </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
             </table>
          </div>
          
         <div class="w-[100%] flex flex-col gap-[10px] md:gap-[0] md:flex-row justify-between mt-[30px]w-[100%] flex flex-col gap-[10px] md:gap-[0] md:flex-row justify-between mt-[30px]">
            <h2 class="text-[14px] text-[#808080] font-[500]">Showing <?php echo e($allConversions->firstItem()); ?> to <?php echo e($allConversions->lastItem()); ?> of <?php echo e($allConversions->total()); ?> records</h2>
            <?php if($allConversions->lastPage() > 1): ?>
    <div class="inline-flex gap-[8px]">
        
        <?php if($allConversions->onFirstPage()): ?>
            <a href="javascript:void(0);" class="group inline-flex gap-[8px] items-center bg-[#F5EAF5] border border-[#FED5C3] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#D272D2] text-center hover:bg-[#D272D2] hover:text-[#fff]"> <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
               <path d="M5 1L1 5L5 9" stroke="#D272D2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="group-hover:stroke-[#fff] "></path>
           </svg>  Previous</span>
        <?php else: ?>
            <a href="<?php echo e($allConversions->previousPageUrl()); ?>" class="group inline-flex gap-[8px] items-center bg-[#F5EAF5] border border-[#FED5C3] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#D272D2] text-center hover:bg-[#D272D2] hover:text-[#fff]"> <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
               <path d="M5 1L1 5L5 9" stroke="#D272D2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="group-hover:stroke-[#fff] "></path>
           </svg> Previous</a>
        <?php endif; ?>

        
        <?php for($i = 1; $i <= $allConversions->lastPage(); $i++): ?>
            <?php if($i == $allConversions->currentPage()): ?>
                <a href="javascript:void(0);" class="btn-active btn inline-flex gap-[8px] items-center bg-[#fff] border border-[#E6E6E6] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#808080] text-center hover:bg-[#D272D2] hover:text-[#fff]"><?php echo e($i); ?></a>
            <?php else: ?>
                <a href="<?php echo e($allConversions->url($i)); ?>" class="btn inline-flex gap-[8px] items-center bg-[#fff] border border-[#E6E6E6] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#808080] text-center hover:bg-[#D272D2] hover:text-[#fff]"><?php echo e($i); ?></a>
            <?php endif; ?>
        <?php endfor; ?>

        
        <?php if($allConversions->hasMorePages()): ?>
            <a class="group inline-flex gap-[5px] items-center bg-[#F5EAF5] border border-[#FED5C3] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#D272D2] text-center hover:bg-[#D272D2] hover:text-[#fff]" href="<?php echo e($allConversions->nextPageUrl()); ?>">Next <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
               <path d="M1 1L5 5L1 9" stroke="#D272D2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="group-hover:stroke-[#fff] "></path>
           </svg></a>
        <?php else: ?>
            <a href="#" class="group inline-flex gap-[5px] items-center bg-[#F5EAF5] border border-[#FED5C3] rounded-[5px] px-[10px] py-[4px] text-[12px] font-[600] text-[#D272D2] text-center hover:bg-[#D272D2] hover:text-[#fff]">Next <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
               <path d="M1 1L5 5L1 9" stroke="#D272D2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="group-hover:stroke-[#fff] "></path>
           </svg></a>
        <?php endif; ?>
    </div>
<?php endif; ?>


         </div>
      </div>
   </div>
 </div>
<script>
   var startDate = "<?php echo e($requestedParams['strd']); ?>"
   var endDate = "<?php echo e($requestedParams['endd']); ?>"
    $(document).ready(function() {
      $('.offerOption').select2({
         placeholder: "Select an offer",
         allowClear: true // Adds a clear (X) button
      });
      $('.countryOptions').select2({
         placeholder: "Select country",
         allowClear: true // Adds a clear (X) button
      });
      $('.osOption').select2({
         placeholder: "Select OS",
         allowClear: true // Adds a clear (X) button
      });
      $('.conversionstatusOption').select2({
         placeholder: "Select status",
         allowClear: true // Adds a clear (X) button
      });
      $('.appendAffiliateApps').select2({
         placeholder: "Select an app",
         allowClear: true // Adds a clear (X) button
      });

      $("#exportCsvBtn").click(function () {
         let exportData = <?php echo json_encode($exportedData, 15, 512) ?>; 
         $.ajax({
               url: "<?php echo e(route('report.export')); ?>",
               type: "POST",
               data: {
                  exportType: 'conversion',
                  exportData: exportData,
                  _token: "<?php echo e(csrf_token()); ?>"
               },
               xhrFields: {
                  responseType: 'blob' 
               },
               success: function (data) {
                  let blob = new Blob([data], { type: "text/csv" });
                  let link = document.createElement("a");
                  link.href = window.URL.createObjectURL(blob);
                  link.download = "report.csv";
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
               },
               error: function () {
                  alert("Error exporting data!");
               }
         });
      });

      $('.dateRange-report').daterangepicker({
         ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
         },
         autoUpdateInput: true, 
         startDate: startDate,  // Default start date (7 days ago)
         endDate: endDate,
         opens: 'right'
      }, function(start, end, label) {
         console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
      });
   });
   $('#filterConversions').on('submit',function(){
      $('.loader-fcustm').show();
   })
   
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/rahulchouhan/Workspace/offerwall-affiliate/resources/views/reports/conversions.blade.php ENDPATH**/ ?>