<div class="w-[100%] px-[15px] md:px-[25px] lg:px-[35px] py-[15px] md:py-[20px] text-[14px] font-[400] text-[#919191] bg-[#fff] fixed bottom-[0]">
&copy; Copyright <?php echo date('Y'); ?>
</div><?php /**PATH /Users/rahulchouhan/Workspace/offerwall-affiliate/resources/views/layouts/footer.blade.php ENDPATH**/ ?>