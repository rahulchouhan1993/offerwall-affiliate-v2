<?php
    use App\Models\Setting;
    $settingsDetails = Setting::find(1);
?>
<div class="bg-[#090B13] pl-[20px] pr-[20px] 2xl:pl-[20px] 2xl:pr-[20px] py-[10px] 2xl:py-[10px] pt-[2px] sidebar">
    <div class="mb-[20px] 2xl:mb-[50px]">
        <a href="<?php echo e(route('dashboard.index')); ?>"
            class=" group flex items-center gap-[10px] px-[10px] py-[10px] text-[16px] font-[400] text-[#918191] hover:text-[#ce68ce] <?php if(Route::currentRouteName()=='dashboard.index'): ?> active <?php endif; ?>">
            <svg width="18" height="19" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M8.07233 2.74306V6.32458C8.07233 6.62113 8.01377 6.91477 7.9 7.18863C7.78624 7.46249 7.61951 7.71119 7.40938 7.92046C7.19926 8.12973 6.94988 8.29544 6.67555 8.40808C6.40123 8.52072 6.10735 8.57808 5.8108 8.57687H2.24775C1.952 8.57866 1.65893 8.52072 1.38611 8.40652C1.1133 8.29232 0.866345 8.1242 0.660067 7.91226C0.450636 7.70457 0.284786 7.45715 0.172245 7.18452C0.0597036 6.91188 0.00273738 6.61952 0.00468708 6.32458V2.75229C0.00468207 2.15654 0.240709 1.58506 0.661101 1.16294C1.08149 0.740814 1.652 0.502442 2.24775 0.5H5.82003C6.11548 0.500284 6.40793 0.559171 6.68045 0.673253C6.95298 0.787334 7.20017 0.954343 7.40771 1.16461C7.6177 1.37044 7.78462 1.61601 7.89872 1.88701C8.01283 2.15802 8.07184 2.44902 8.07233 2.74306ZM17.9953 2.75229V6.32458C17.9906 6.91885 17.753 7.48756 17.3336 7.90865C16.9143 8.32974 16.3465 8.56964 15.7523 8.57687H12.1708C11.5737 8.57322 11.0013 8.3383 10.5738 7.92149C10.365 7.71148 10.1996 7.46233 10.0871 7.18831C9.97464 6.91429 9.91734 6.62078 9.91847 6.32458V2.75229C9.91772 2.4567 9.97614 2.16394 10.0903 1.89127C10.2044 1.6186 10.372 1.37153 10.5831 1.16461C10.7906 0.954343 11.0378 0.787334 11.3103 0.673253C11.5829 0.559171 11.8753 0.500284 12.1708 0.5H15.743C16.3389 0.504825 16.909 0.743669 17.3303 1.16501C17.7517 1.58636 17.9905 2.15644 17.9953 2.75229ZM17.9953 12.6753V16.2476C17.9906 16.8419 17.753 17.4106 17.3336 17.8317C16.9143 18.2527 16.3465 18.4927 15.7523 18.4999H12.1708C11.5699 18.506 10.9904 18.2775 10.5554 17.863C10.3457 17.6536 10.1797 17.4045 10.0672 17.1304C9.9547 16.8562 9.89786 16.5624 9.90001 16.266V12.6938C9.89926 12.3982 9.95768 12.1054 10.0718 11.8327C10.186 11.5601 10.3535 11.313 10.5646 11.1061C10.7722 10.8958 11.0194 10.7288 11.2919 10.6147C11.5644 10.5006 11.8569 10.4418 12.1523 10.4415H15.7246C16.3204 10.4463 16.8905 10.6851 17.3119 11.1065C17.7332 11.5278 17.9721 12.0979 17.9769 12.6938L17.9953 12.6753ZM8.07233 12.6845V16.2568C8.06506 16.8527 7.82389 17.4218 7.40081 17.8414C6.97774 18.261 6.40668 18.4975 5.8108 18.4999H2.24775C1.95284 18.5011 1.66062 18.4439 1.38792 18.3316C1.11523 18.2193 0.867473 18.0542 0.658942 17.8456C0.450411 17.6371 0.285235 17.3893 0.172943 17.1166C0.0606508 16.844 0.00346592 16.5517 0.00468708 16.2568V12.6845C0.0070651 12.0887 0.243571 11.5176 0.66319 11.0945C1.08281 10.6715 1.65191 10.4303 2.24775 10.423H5.82003C6.41837 10.4291 6.99094 10.6674 7.41695 11.0876C7.83795 11.5123 8.0736 12.0865 8.07233 12.6845Z"
                    fill="currentColor" />
            </svg>
            Dashboard
        </a>
    </div>

    <div class="mb-[20px] 2xl:mb-[50px]">
        <h2 class="text-[12px] font-[600] text-[#918191] uppercase mb-[5px] px-[10px]">REPORTS</h2>
        <a href="<?php echo e(route('report.statistics')); ?>"
            class="group flex items-center gap-[10px] px-[10px] py-[10px] text-[16px] font-[400] text-[#918191] hover:text-[#ce68ce] <?php if(Route::currentRouteName()=='report.statistics'): ?> active <?php endif; ?>">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M19 18C19 18.5523 18.5523 19 18 19H2C1.44772 19 1 18.5523 1 18C1 17.4477 1.44772 17 2 17H18C18.5523 17 19 17.4477 19 18ZM6 9C6 8.44772 5.55228 8 5 8H3C2.44772 8 2 8.44772 2 9V14C2 14.5523 2.44772 15 3 15H5C5.55228 15 6 14.5523 6 14V9ZM12 2C12 1.44772 11.5523 1 11 1H9C8.44772 1 8 1.44772 8 2V14C8 14.5523 8.44772 15 9 15H11C11.5523 15 12 14.5523 12 14V2ZM18 5C18 4.44772 17.5523 4 17 4H15C14.4477 4 14 4.44772 14 5V14C14 14.5523 14.4477 15 15 15H17C17.5523 15 18 14.5523 18 14V5Z"
                    fill="currentColor" />
            </svg> Statistics
        </a>
        <?php if($settingsDetails->conversion_report==1): ?>
        <a href="<?php echo e(route('report.conversions')); ?>"
            class="group flex items-center gap-[10px] px-[10px] py-[10px] text-[16px] font-[400] text-[#918191] hover:text-[#ce68ce] <?php if(Route::currentRouteName()=='report.conversions'): ?> active <?php endif; ?>">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M21.5 11.5V7C21.5 6.73478 21.3946 6.48043 21.2071 6.29289C21.0196 6.10536 20.7652 6 20.5 6H12L9.5 3H3.5C3.23478 3 2.98043 3.10536 2.79289 3.29289C2.60536 3.48043 2.5 3.73478 2.5 4V20C2.5 20.2652 2.60536 20.5196 2.79289 20.7071C2.98043 20.8946 3.23478 21 3.5 21H11M13.5 15.5H20.5L18 13M20.5 18.5H13.5L16 21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>

            Conversions
        </a>
        <?php endif; ?>
        <?php if($settingsDetails->postback_report==1): ?>
        <a href="<?php echo e(route('report.postbacks')); ?>"
            class="group flex items-center gap-[10px] px-[10px] py-[10px] text-[16px] font-[400] text-[#918191] hover:text-[#ce68ce] <?php if(Route::currentRouteName()=='report.postbacks'): ?> active <?php endif; ?>">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M1 10C1 14.9703 5.02966 19 10 19C14.9703 19 19 14.9703 19 10C19 5.02966 14.9703 1 10 1C5.02966 1 1 5.02966 1 10ZM11.9038 14.6848L6.27495 10L11.9038 5.31524V14.6848Z"
                    fill="currentColor" />
            </svg>
            Postbacks
        </a>
        <?php endif; ?>
        
    </div>
    <div class="mb-[20px] 2xl:mb-[50px]">
        <h2 class="text-[12px] font-[600] text-[#918191] uppercase mb-[5px] px-[10px]">APPS</h2>
        <a href="<?php echo e(route('apps.index')); ?>"
            class="group flex items-center gap-[10px] px-[10px] py-[10px] text-[16px] font-[400] text-[#918191] hover:text-[#ce68ce] <?php if(Route::currentRouteName()=='apps.index'): ?> active <?php endif; ?>">
            <svg width="20" height="16" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M5.55556 2.44444C5.24074 2.44444 4.97704 2.33777 4.76445 2.12444C4.55186 1.9111 4.44519 1.6474 4.44445 1.33332C4.44371 1.01925 4.55037 0.755547 4.76445 0.542214C4.97852 0.328881 5.24223 0.222214 5.55556 0.222214H18.8889C19.2037 0.222214 19.4678 0.328881 19.6811 0.542214C19.8944 0.755547 20.0007 1.01925 20 1.33332C19.9993 1.6474 19.8926 1.91147 19.68 2.12555C19.4674 2.33962 19.2037 2.44592 18.8889 2.44444H5.55556ZM5.55556 9.1111C5.24074 9.1111 4.97704 9.00444 4.76445 8.7911C4.55186 8.57777 4.44519 8.31407 4.44445 7.99999C4.44371 7.68592 4.55037 7.42221 4.76445 7.20888C4.97852 6.99555 5.24223 6.88888 5.55556 6.88888H18.8889C19.2037 6.88888 19.4678 6.99555 19.6811 7.20888C19.8944 7.42221 20.0007 7.68592 20 7.99999C19.9993 8.31407 19.8926 8.57814 19.68 8.79221C19.4674 9.00629 19.2037 9.11258 18.8889 9.1111H5.55556ZM5.55556 15.7778C5.24074 15.7778 4.97704 15.6711 4.76445 15.4578C4.55186 15.2444 4.44519 14.9807 4.44445 14.6667C4.44371 14.3526 4.55037 14.0889 4.76445 13.8755C4.97852 13.6622 5.24223 13.5555 5.55556 13.5555H18.8889C19.2037 13.5555 19.4678 13.6622 19.6811 13.8755C19.8944 14.0889 20.0007 14.3526 20 14.6667C19.9993 14.9807 19.8926 15.2448 19.68 15.4589C19.4674 15.673 19.2037 15.7793 18.8889 15.7778H5.55556ZM1.11111 2.44444C0.7963 2.44444 0.532597 2.33777 0.320004 2.12444C0.107411 1.9111 0.000744572 1.6474 3.83141e-06 1.33332C-0.000736909 1.01925 0.10593 0.755547 0.320004 0.542214C0.534078 0.328881 0.797782 0.222214 1.11111 0.222214C1.42445 0.222214 1.68852 0.328881 1.90334 0.542214C2.11815 0.755547 2.22445 1.01925 2.22223 1.33332C2.22 1.6474 2.11334 1.91147 1.90223 2.12555C1.69111 2.33962 1.42741 2.44592 1.11111 2.44444ZM1.11111 9.1111C0.7963 9.1111 0.532597 9.00444 0.320004 8.7911C0.107411 8.57777 0.000744572 8.31407 3.83141e-06 7.99999C-0.000736909 7.68592 0.10593 7.42221 0.320004 7.20888C0.534078 6.99555 0.797782 6.88888 1.11111 6.88888C1.42445 6.88888 1.68852 6.99555 1.90334 7.20888C2.11815 7.42221 2.22445 7.68592 2.22223 7.99999C2.22 8.31407 2.11334 8.57814 1.90223 8.79221C1.69111 9.00629 1.42741 9.11258 1.11111 9.1111ZM1.11111 15.7778C0.7963 15.7778 0.532597 15.6711 0.320004 15.4578C0.107411 15.2444 0.000744572 14.9807 3.83141e-06 14.6667C-0.000736909 14.3526 0.10593 14.0889 0.320004 13.8755C0.534078 13.6622 0.797782 13.5555 1.11111 13.5555C1.42445 13.5555 1.68852 13.6622 1.90334 13.8755C2.11815 14.0889 2.22445 14.3526 2.22223 14.6667C2.22 14.9807 2.11334 15.2448 1.90223 15.4589C1.69111 15.673 1.42741 15.7793 1.11111 15.7778Z"
                    fill="currentColor" />
            </svg>
            App List
        </a>

        <a href="<?php echo e(route('apps.add')); ?>"
            class="group flex items-center gap-[10px] px-[10px] py-[10px] text-[16px] font-[400] text-[#918191] hover:text-[#ce68ce] <?php if(Route::currentRouteName()=='apps.add'): ?> active <?php endif; ?>">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M11.6667 11.6667V8.33333H8.33333V7.22222H11.6667V3.88889H12.7778V7.22222H16.1111V8.33333H12.7778V11.6667H11.6667ZM1.79556 20C1.2837 20 0.856667 19.8289 0.514444 19.4867C0.172222 19.1444 0.000740741 18.7174 0 18.2056V6.23889C0 5.72778 0.171482 5.30111 0.514444 4.95889C0.857407 4.61667 1.28407 4.44519 1.79444 4.44444H4.01667V1.79556C4.01667 1.2837 4.18815 0.856667 4.53111 0.514445C4.87407 0.172222 5.30111 0.000740741 5.81222 0H18.2056C18.7167 0 19.1437 0.171482 19.4867 0.514445C19.8296 0.857408 20.0007 1.28407 20 1.79444V14.1889C20 14.7 19.8289 15.127 19.4867 15.47C19.1444 15.813 18.7174 15.9844 18.2056 15.9844H15.5556V18.2067C15.5556 18.7178 15.3844 19.1444 15.0422 19.4867C14.7 19.8289 14.273 20 13.7611 20H1.79556ZM5.81222 14.8722H18.2056C18.3759 14.8722 18.5326 14.8007 18.6756 14.6578C18.8185 14.5148 18.8896 14.3585 18.8889 14.1889V1.79444C18.8889 1.62407 18.8178 1.46741 18.6756 1.32444C18.5333 1.18148 18.3767 1.11037 18.2056 1.11111H5.81111C5.64074 1.11111 5.48444 1.18222 5.34222 1.32444C5.2 1.46667 5.12889 1.62333 5.12889 1.79444V14.1889C5.12889 14.36 5.2 14.5167 5.34222 14.6589C5.48444 14.8011 5.64111 14.8715 5.81222 14.8722Z"
                    fill="currentColor" />
            </svg>

            Add App
        </a>

        <a href="<?php echo e(route('testPostback')); ?>"
            class="group flex items-center gap-[10px] px-[10px] py-[10px] text-[16px] font-[400] text-[#918191] hover:text-[#ce68ce] <?php if(Route::currentRouteName()=='testPostback'): ?> active <?php endif; ?>">
            <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M15.3345 15.4512C15.4165 15.5859 15.478 15.7236 15.519 15.8643C15.5601 16.0049 15.5806 16.1543 15.5806 16.3125C15.5806 16.5469 15.5366 16.7666 15.4487 16.9717C15.3608 17.1768 15.2407 17.3555 15.0884 17.5078C14.936 17.6602 14.7573 17.7803 14.5522 17.8682C14.3472 17.9561 14.1274 18 13.8931 18H2.10693C1.87256 18 1.65283 17.9561 1.44775 17.8682C1.24268 17.7803 1.06396 17.6602 0.911621 17.5078C0.759277 17.3555 0.63916 17.1768 0.55127 16.9717C0.463379 16.7666 0.419434 16.5469 0.419434 16.3125C0.419434 16.1543 0.437012 16.0049 0.472168 15.8643C0.507324 15.7236 0.568848 15.5859 0.656738 15.4512L5.65771 6.73242C5.71631 6.65039 5.74561 6.55078 5.74561 6.43359V1.125H4.62061V0H11.3706V1.125H10.2456V6.43359C10.2456 6.54492 10.2749 6.64746 10.3335 6.74121L15.3345 15.4512ZM6.87061 6.43359C6.87061 6.74414 6.7915 7.03418 6.6333 7.30371L3.72412 12.375H12.2671L9.35791 7.30371C9.19971 7.03418 9.12061 6.74414 9.12061 6.43359V1.125H6.87061V6.43359Z"
                    fill="currentColor" />
            </svg>

            Test Postback
        </a>
        
    </div>
    <div class="mb-[20px] 2xl:mb-[50px]">
        <h2 class="text-[12px] font-[600] text-[#918191] uppercase mb-[5px] px-[10px]">Support</h2>
        

        <a href="<?php echo e(route('documentations')); ?>"
            class="group flex items-center gap-[10px] px-[10px] py-[10px] text-[16px] font-[400] text-[#918191] hover:text-[#ce68ce] <?php if(Route::currentRouteName()=='documentations'): ?> active <?php endif; ?>">
            <svg width="18" height="20" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M1.172 1.172C-1.19209e-07 2.343 0 4.229 0 8V12C0 15.771 -1.19209e-07 17.657 1.172 18.828C2.344 19.999 4.229 20 8 20H10C13.771 20 15.657 20 16.828 18.828C17.999 17.656 18 15.771 18 12V8C18 4.229 18 2.343 16.828 1.172C15.656 0.000999928 13.771 0 10 0H8C4.229 0 2.343 -1.19209e-07 1.172 1.172ZM5 7.25C4.80109 7.25 4.61032 7.32902 4.46967 7.46967C4.32902 7.61032 4.25 7.80109 4.25 8C4.25 8.19891 4.32902 8.38968 4.46967 8.53033C4.61032 8.67098 4.80109 8.75 5 8.75H13C13.1989 8.75 13.3897 8.67098 13.5303 8.53033C13.671 8.38968 13.75 8.19891 13.75 8C13.75 7.80109 13.671 7.61032 13.5303 7.46967C13.3897 7.32902 13.1989 7.25 13 7.25H5ZM5 11.25C4.80109 11.25 4.61032 11.329 4.46967 11.4697C4.32902 11.6103 4.25 11.8011 4.25 12C4.25 12.1989 4.32902 12.3897 4.46967 12.5303C4.61032 12.671 4.80109 12.75 5 12.75H10C10.1989 12.75 10.3897 12.671 10.5303 12.5303C10.671 12.3897 10.75 12.1989 10.75 12C10.75 11.8011 10.671 11.6103 10.5303 11.4697C10.3897 11.329 10.1989 11.25 10 11.25H5Z"
                    fill="currentColor" />
            </svg>


            Documentation
        </a>



    </div>

</div>
<div id="popupModal" class="fixed inset-0 bg-gray-900 bg-opacity-50 flex items-center justify-center hidden z-[999]">
    <div class="relative bg-white w-[95%] max-w-[600px] p-[20px] rounded-[10px] shadow-lg">
    <button id="closeModal" class="absolute flex items-center justify-center top-[-6px] right-[-6px] lg:top-[-10px] lg:right-[-10px] w-[35px] h-[35px]  bg-[#D272D2] rounded-[60px] text-[14px] font-[500] text-[#fff] text-center">
      <i class="ri-close-large-line"></i>
      </button>

      <h2 class="mb-[15px] text-[20px] text-[#1A1A1A] font-[600] ">
      Test Postback    
        </h2>   
    
    <div class="flex flex-col gap-[15px] w-[100%] ">
                <div class="flex flex-wrap md:flex-nowrap gap-[20px] w-[100%">
                    <div class="flex flex-col gap-[5px] w-[100%]">
                        <label class="text-[14] text-[#898989]">Postback for <span class="text-[#f00000] text-[12px] mt-[-5px]">*</span></label>
                        <input type="text" name="Postback" class="flex px-[15px] py-[12px] rounded-[5px] bg-[#F6F6F6] text-[14px] text-[#4D4D4D] font-[600] hover:outline-none focus:outline-none">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="color: red;"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="flex gap-[20px] w-[100%">
                    <div class="flex flex-col gap-[5px] w-[100%]">
                    <label class="text-[14] text-[#898989]">Clickid <span class="text-[#f00000] text-[12px] mt-[-5px]">*</span></label>
                        <input type="text" name="Clickid" class="flex px-[15px] py-[12px] rounded-[5px] bg-[#F6F6F6] text-[14px] text-[#4D4D4D] font-[600] hover:outline-none focus:outline-none">
                      
                    </div>
                </div>

                <div class="flex gap-[20px] w-[100%">
                    <div class="flex flex-col gap-[5px] w-[100%]">
                    <label class="text-[14] text-[#898989]">Payout</label>
                    <input type="text" name="Payout" class="flex px-[15px] py-[12px] rounded-[5px] bg-[#F6F6F6] text-[14px] text-[#4D4D4D] font-[600] hover:outline-none focus:outline-none" >
                    </div>
                </div>

                <div class="flex gap-[10px] md:gap-[20px]">
                    <button type="submit" class=" bg-[#D272D2] px-[10px] py-[11px] w-[150px] rounded-[4px] text-[14px] font-[500] text-[#fff] text-center">Send the Postback</button>
                </div>
            </div>
        </div>
    </div>
<script>
    // Elements
    const openModalButton = document.getElementById('openModal');
    const closeModalButton = document.getElementById('closeModal');
    const modal = document.getElementById('popupModal');

    // Open Modal
    openModalButton.addEventListener('click', () => {
      modal.classList.remove('hidden');
    });

    // Close Modal
    closeModalButton.addEventListener('click', () => {
      modal.classList.add('hidden');
    });

    // Close Modal by clicking outside of it
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.add('hidden');
      }
    });
  </script><?php /**PATH /Users/rahulchouhan/Workspace/offerwall-affiliate-v2/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>